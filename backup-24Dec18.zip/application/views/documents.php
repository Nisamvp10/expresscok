
<ol class="breadcrumb">
    <li><a href="<?php echo base_url();?>">Home</a></li> 
    <li class="active">Documents</li>
</ol>
<div class="about-section" style="margin-bottom: 50px;">

    <div class="e-payment-section">
        <div class="payment-left">
            <div class="confirm-details">
                <div class="row">
                    <h3 style="margin-bottom:10px;padding-left: 15px;">Documents</h3>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Express Brochure</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                    <a href="<?php echo resource('frontend')?>documents/Express Brochure.pdf" target="_blank">
                                        <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                    </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Commercial Invoice</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/commercial-invoice.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                    <a href="<?php echo resource('frontend')?>documents/commercial-invoice.pdf" target="_blank">
                                        <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                    </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">SDF Form</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sdf-form.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sdf-form.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">SLI OM</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-om.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-om.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">SLI Fedex</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-fedex.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-fedex.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Non DG Decl & SLI of DHL</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/non-dg-decl-&-sli-of-dhl.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/non-dg-decl-&-sli-of-dhl.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Annexure II for Drawback</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/annexure-II-for-drawback.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/annexure-II-for-drawback.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">GR Waiver Form (for Free Trade Sample)</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/gr-waiver-form-(for-free-trade-sample).xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/gr-waiver-form-(for-free-trade-sample).pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Non DG DECL</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/non-dg-decl.doc" download>
                                    <img src="<?php echo resource('frontend')?>images/word.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/non-dg-decl.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">SLI Format 14 Aug 2017</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/SLI_Format.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Packing List</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/packing-list.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/packing-list.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Export Value Dec</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/export-value-dec.doc" download>
                                    <img src="<?php echo resource('frontend')?>images/word.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/export-value-dec.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">SLI TNT</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-tnt.doc" download>
                                    <img src="<?php echo resource('frontend')?>images/word.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-tnt.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">SLI UPS</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-ups.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/sli-ups.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Annexure I for Drawback</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/annexure-I-for-drawback.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/annexure-I-for-drawback.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">ACD Format</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/acd-format.xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/acd-format.pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">GR Waiver Form (for Repair & Return)</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/gr-waiver-form-(for-repair-&-return).xls" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/gr-waiver-form-(for-repair-&-return).pdf" target="_blank">
                                    <img src="<?php echo resource('frontend')?>images/view.png" style="float: right;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Customs Invoice for Formal Shipment 8 Aug 2017</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/Customs_Invoice_for_Formal_Shipment.xlsx" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">Invoice For SCB II shipments</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/Invoice_For_SCB_II_shipments.xlsx" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-10 col-sm-10 col-xs-10">
                                <p style="float: left;">NEW GST INVOICE DHL</p>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                <a href="<?php echo resource('frontend')?>documents/NEW_GST_INVOICE_DHL.xlsx" download>
                                    <img src="<?php echo resource('frontend')?>images/excel.png" style="float: right;"/>
                                </a>
                            </div>
                            <div class="col-md-1 col-sm-1 col-xs-1">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <!--start-carrer-->
    <!----- Comman-js-files ----->
    <script>
        $(document).ready(function () {
            $("#tab2").hide();
            $("#tab3").hide();
            $("#tab4").hide();
            $(".tabs-menu a").click(function (event) {
                event.preventDefault();
                var tab = $(this).attr("href");
                $(".tab-grid").not(tab).css("display", "none");
                $(tab).fadeIn("slow");
            });
        });
    </script>
</div>

<p class="sed-para fa fa-phone"> Phone : </p>
            <p class="para1"> Call Now for any query 0484-4000071 </p>
            <p class="para1">  7403005001 </p>
            <p class="sed-para fa fa-envelope"> Email : </p>
            <p class="para1">  expresscok@gmail.com </p>
