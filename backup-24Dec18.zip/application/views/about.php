

<iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fexpressinternationalcourier&width=63&layout=box_count&action=like&size=large&show_faces=true&share=true&height=65&appId" width="63" height="65" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

<ol class="breadcrumb">
    <li><a href="<?php echo base_url();?>">Home</a></li> 
    <li class="active">About Us</li>
</ol>
<!----->
<div class="about-section">

    <div class="e-payment-section">
        <div class="col-md-8 col-sm-8 col-xs-12 payment-left">
            <div class="confirm-details col-lg-12">
                <h3 style="margin-bottom:10px;">About Us</h3>
                <p style="text-align:justify;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">
                    <img src="<?php echo resource('frontend')?>images/r4.jpg" height="150px" style="float:left; margin-right:10px; margin-top:4px;width: 240px;height: 140px;" /> Ex Courier India Private Limited Group Express International helps retail couriers to increase their profits. We are the only independent wholesale express company in India, and one of the oldest in the world. Our 25+ years of expertise and versatile range of services enable couriers to deliver their shipments with more speed, reliability and cost-efficiency. Talk to us today and discover how we can add value to your business.
                </p>
<!--                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">The first load carried from Tamil Nadu to Karnataka and in the subsequent years made them to expand our services from Tamilnadu to New Delhi, Uttar Pradesh, Rajasthan, Haryana, Uttaranchal, Punjab, and Jammu & Kashmir successfully. </p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">The fastest service and personal attention to every need has earned a Name in the market. The continued supports of our clients give confidence to start M/s SSPT LOGISTICS with additional value added services at a nominal rate and efficient execution to our ever increasing Client list.</p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">
                    To maintain continued services, we have added multi axle & Container Trucks to our fleet. Subsequently opened our state of the art workshop with Company trained workforce to maintain healthy fleet and added our own body building unit. </p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">Now we are operating more than 150 branches across the country. All our trucks are fitted with Electronic Tracking Devices, to locate the consignments and the trucks, at your finger tips to a Smart Phones.</p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">Presently, we have more than 500 multi-axel trucks includes container trucks running’s through the highways of country driven by company trained drivers. We are handling more than 1 lack tonnes of Merchandise monthly with efficiency and economically.</p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">The SSPT LOGISTICS earned the reputation for our commitment in Service. We can carry from 1 tons to 100 tons, irrespective of quantity through Open body, Container or by Trailer trucks to any location in the Country.</p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">For faster information, all our branches are connected to network for easy accessibility to information and avoid anxiety of the where about of goods. Our team of experienced professionals supervise all the activities to maintain the best services up to the customer’s satisfaction.</p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">Apart from this we are operating our Value Added Services such as, Train cargo, Express cargo, Door to Door services and Contract Transportation of merchandise of any kind, most reliably and efficiently.</p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">
                    We have ISO Certification to our credit and won an award as the best Fleet Management of the year in 2015.
                </p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">
                    We assure you the best services at a reasonable cost. We request all over clients to point out our short fall to us and tell our quality of service to your trade partners. Your suggestion would make us improve further to excel in profession. 
                </p>
                <p style="text-align:justify; margin-top:10px;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">Constant Improvement of Quality of Service is Our Aim, which makes SSPT LOGISTICS remain Best amongst the Rest.</p>-->
            </div>
            <div class="payment-options col-lg-12" >
                <div class="tabs-box">
                    <ul class="tabs-menu booking-menu">
                        <li><a href="#tab1" style="color:#0094ff;"><b>Our History</b></a></li>
                        <li><a href="#tab2" style="color:#0094ff;"><b>Our Mission</b></a></li>
                        <li><a href="#tab3" style="color:#0094ff;"><b>What We Do</b></a></li>
                    </ul>
                    <div class="clearfix"> </div>
                    <div class="tab-grids event-tab-grids">
                        <div id="tab1" class="tab-grid">
                            <p style="text-align:justify;"><img src="<?php echo resource('frontend')?>images/images.jpeg" style="float:left; margin-right:10px;width: 170px;height: 100px;" />As one of the world’s oldest and largest independent wholesale express companies, Express International enjoys a solid reputation built upon a quarter century of reliability, trust and efficiency.With operations in the UAE, Singapore, Kenya and Africa, our primary distribution area covers some of the world’s fastest growing markets and a population of about three billion people.We provide retail couriers and freight-forwarders with reliable service to profitably develop their trade lanes across the world, with express door-to-door delivery of documents and parcels to over 220 countries – many of them on a same-day or next-day basis.</p>
                        </div>
                        <div id="tab2" class="tab-grid"><p style="text-align:justify;"><img src="<?php echo resource('frontend')?>images/mission_v5.png" style="float:left; margin-right:10px;" />We are proud to be recognized as the India’s oldest independent wholesale express company – twenty-five years and counting – but what brings us even greater pleasure is our reputation for superb service.Our head office is in Kerala, the commercial center of the Kochi, partnering with our clients to support their businesses in the India, Middle East, Asia and USA. Our distribution footprint spans the world’s fastest growing markets and economies, and for more than twenty-five years we have grown and expanded by offering fast and reliable delivery times, competitive rates and first-class customer service.</p>
                        </div>
                        <div id="tab3" class="tab-grid">
                            <p style="text-align:justify;"><img src="<?php echo resource('frontend')?>images/expertise_v5.png" style="float:left; margin-right:10px;width: 170px;height: 150px;" />Whether your business is already in key growth markets, or whether you are expanding your market opportunities, whether you require standard line-haul facilities, or comprehensive door-to-door support. Express International has the specialist knowledge, the network and the rates to help you increase your revenue, and your profits.We look forward to partnering with you and adding tangible value to your business.</p>

                        </div>
<!--                        <div id="tab4" class="tab-grid">
                            <div class="row">
                                <div class="col-md-6">
                                    <img class="pp-img" src="images/paypal.png" alt="Image Alternative text" title="Image Title">
                                    <p>Important: You will be redirected to PayPal's website to securely complete your payment.</p><a class="btn btn-primary">Checkout via Paypal</a>	
                                </div>
                                <div class="col-md-6">
                                    <form class="cc-form">
                                        <div class="clearfix">
                                            <div class="form-group form-group-cc-number">
                                                <label>Card Number</label>
                                                <input class="form-control" placeholder="xxxx xxxx xxxx xxxx" type="text"><span class="cc-card-icon"></span>
                                            </div>
                                            <div class="form-group form-group-cc-cvc">
                                                <label>CVV</label>
                                                <input class="form-control" placeholder="xxxx" type="text">
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                            <div class="form-group form-group-cc-name">
                                                <label>Card Holder Name</label>
                                                <input class="form-control" type="text">
                                            </div>
                                            <div class="form-group form-group-cc-date">
                                                <label>Valid Thru</label>
                                                <input class="form-control" placeholder="mm/yy" type="text">
                                            </div>
                                        </div>
                                        <div class="checkbox checkbox-small">
                                            <label>
                                                <input class="i-check" type="checkbox" checked="">Add to My Cards</label>
                                        </div>
                                        <input class="btn btn-primary" type="submit" value="Proceed Payment">
                                    </form>
                                </div>
                            </div>
                        </div>-->
                    </div>			
                    <div class="clearfix"> </div>
                </div>
                <!--start-carrer-->
                <!----- Comman-js-files ----->
                <script>
                    $(document).ready(function () {
                        $("#tab2").hide();
                        $("#tab3").hide();
                        $("#tab4").hide();
                        $(".tabs-menu a").click(function (event) {
                            event.preventDefault();
                            var tab = $(this).attr("href");
                            $(".tab-grid").not(tab).css("display", "none");
                            $(tab).fadeIn("slow");
                        });
                    });
                </script>

            </div>
        </div>
        <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="col-md-12 col-sm-12 col-xs-12 right_panel">
            <div class="express_tab">Express</div>  
            <div class="col-md-12 col-sm-12 col-xs-12 track_div_arg">
                <h5 class="fa fa-minus-square" style="float: left;padding: 5px 0px 0px 10px;">&nbsp;Track Your Shipment</h5>
				<form enctype="multipart/form-data" method="post" action="track_order">
					<div id="reply">
					<?php $field_data=array();if($this->session->flashdata('error')){
						$field_data=$this->session->flashdata('value');
						echo $this->session->flashdata('error');
					 } ?>
					</div>
					<input  type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();  ?>"> 
                    <textarea placeholder="Enter tracking number(s)" name="track_id"></textarea>
					<input type="hidden" value="<?php echo current_url();?>" name="rurl" />
                    <button type="submit" >Track </button>
                    <h6>Track upto 10 numbers at a time. Separate with a comma (,) or return (enter).</h6>
                </form>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <a class="fa fa-arrow-right" style="float: left;">&nbsp;More Tracking Options</a><br>
                    <a href="/contact" class="fa fa-arrow-right" style="float: left;">&nbsp;Contact Express Courier</a>
                </div>
            </div>
        </div>
    </div>
        <div class="clearfix"></div>
    </div>
    <!--start-carrer-->
    <!----- Comman-js-files ----->
    <script>
        $(document).ready(function () {
            $("#tab2").hide();
            $("#tab3").hide();
            $("#tab4").hide();
            $(".tabs-menu a").click(function (event) {
                event.preventDefault();
                var tab = $(this).attr("href");
                $(".tab-grid").not(tab).css("display", "none");
                $(tab).fadeIn("slow");
            });
        });
    </script>
</div>
<iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fexpressinternationalcourier&width=63&layout=box_count&action=like&size=large&show_faces=true&share=true&height=65&appId" width="63" height="65" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>