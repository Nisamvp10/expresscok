					<div class="footer-grid" style="padding-bottom: 20px;">
                    
                        <div class="clearfix"></div>			
                    </div>

                </div>


                <div class="clearfix"></div>
            </div>
            <div class="copy-rights text-center">
                <p style="float: right;"><a href="<?php echo base_url();?>">Home</a> | <a href="<?php echo base_url('about');?>">About Us</a> | <a href="<?php echo base_url('tracking');?>">Live Tracking</a> |<a href="<?php echo base_url('contact');?>">Contact Us</a> </p>
                <p style="float: left;">Copyright &copy; 2017 | All Rights Reserved | Designed by <a href="http://www.owebso.com" target="_blank">Owebso</a></p>
            </div>

            <script type="text/javascript">
                            $(document).ready(function () {
                               
                                $().UItoTop({easingType: 'easeOutQuart'});

                            });
            </script>
            <a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

    </body>

    
</html>
