     <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            
                            <small>Ooops! The page you are looking for is not found / temperorily unavailable.</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?php echo base_url();?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i onclick="history.go(-1);" class="fa fa-step-backward"></i><a onclick="history.go(-1);" href="<?php echo base_url();?>"> Previous Page </a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file-excel-o"></i> Not Found
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div style="text-align: center;" class="col-lg-12">
                        <img style="width: 50%;" src="<?php echo resource('backend')?>img/404_c1.png" />
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>