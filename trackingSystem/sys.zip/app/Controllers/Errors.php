<?php
// app/Controllers/Errors.php

namespace App\Controllers;

class Errors extends BaseController
{
    public function show404()
    {
        $message ='Permission Not allowed';
        return view('errors/html/error_404',compact('message')); // Create this view
    }
}
