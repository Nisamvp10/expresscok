<!--  modal Open-->
<div class="modal fade" id="orderModal" tabindex="-1">
    <div class="modal-dialog" style="min-width: 80%;">
      <div class="row rounded-3 overflow-hidden">
      <div class="modal-content">
      
        <div class="row">
        <div class="col-sm-12 m-0 p-0">
            <div class="modal-header">
                <h5 class="modal-title">Order Details <span class="text-info" id="className"></span></h5>
            </div>
            <div class="modal-body">
               
                 <div id="orderInfo"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>

            </div>
        </div>
    
      </div>
     
    
    </div>
    </div> <!--close row -->
    </div>
</div>
<!--M odal Close  -->
