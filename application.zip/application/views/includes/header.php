<!DOCTYPE html>
<html lang="en">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <head><meta charset="windows-1252">
        <?php if(isset($tittle)&&!empty($tittle)){ ?>
        <title><?php echo $tittle; ?></title>
        <?php }  else { ?>
        <title>DHL EXPRESS INTERNATIONAL COURIER & CARGO SERVICE</title>
        <?php } ?>

        <?php
        if (isset($meta_description) && !empty($meta_description)) {
            ?>
            <meta name="description" content="<?php echo $meta_description?>"> 
            <?php
        } else {
            ?>
             <!--<meta name="description" content="Express International COURIER & CARGO SERVICE is the global market leader in the logistics industry. DHL commits its expertise in international parcel, express, air and ocean freight, road and rail transportation, contract logistics and international mail services to its customers."> -->             
             <meta name="description" content="DHL FEDEX TNT UPS ARAMEX FLAT 35 % DISCOUNTS FOR EUROPE, USA, AUSTRALIA, NEW ZEALAND, CHINA SHIPMENTS, REST OF THE COUNTRIES 30% DISCOUNT, CALL 7403005001">
            <?php
        }

       
        ?>
        
            <meta name="google-site-verification" content="o_TYi6PFKbT3M_NeTvBWk2OzBwlzb1PhSbb_2wuFGSA" />


          <meta name="keywords" content="dhl cochin, dhl kerala, dhl express,fedex express,fedex,dhl cochin contact number,international courier services,international,
          courier services cochin ,International dhl,dhl,dhl kochi,dhl ernakulam office,dhl booking ,dhl courier booking ,dhl international courier booking kerala ,international couier booking in kerala ,
international couier booking in kochi,
international couier booking in ernakulam ,
international couier booking in aluva,
international couier booking in thrissur,
international courier services thrissur,
international courier services kozhikode ,
international cargo service ,
biggest cargo agent in kerala ,
biggest cargo agent in kochi,
biggest cargo agent in ernakulam,
fedex courier booking ,
fedex,
aramex courier ,
ups courier booking ,
ups international courier ,
bike parcel service ,
medicine international courier service ,
CHEAPER INTERNATIONAL COURIER SERVICE,
BEST INTERNATIONAL COURIER SERVICES ,
ECONOMY COURIER SERVICES IN  KERALA, 
ECONOMY COURIER SERVICES IN KOCHI ,
INTERNATIONAL COURIER SERVICES ,INTERNATIONAL COURIER SERVICES THRISSUR ,INTERNATIONAL COURIER SERVICES COCHIN ,INTERNATIONAL COURIER SERVICES KOZHIKODE ,INTERNATIONAL COURIER SERVICES ALUVA ,INTERNATIONAL COURIER SERVICES CHALAKUDY ,INTERNATIONAL COURIER SERVICES KOCHI ,INTERNATIONAL COURIER SERVICES ERNAKULAM ,DHL COURIER SERVICES ,DHL COURIER KOCHI ,DHL EXPRESS MG ROAD ,DHL EXPRESS THRISSUR ,DHL THRISSUR ,DHL CHALAKUDY ,DHL COCHIN ,DHL KOCHI ,INTERNATIONAL COURIER SERVICES TO USA ,INTERNATIONAL COURIER SERVICES TO AFRICA ,FEDEX COURIER SERVICES ,FEDEX COURIER KOCHI ,CHEAPEST COURIER SERVICES ,FEDEX EXPRESS MG ROAD ,FEDEX EXPRESS THRISSUR ,FEDEX THRISSUR ,FEDEX CHALAKUDY ,FEDEX COCHIN,FEDEX KOCHI,FEDEX COURIER ,
DHL DIRECT WHOLESELLER ,
DHL WHOLESALE OFFICE ,
INTERNATIONAL COURIER SERVICES AFGANISTAN,
INTERNATIONAL COURIER SERVICES ALBANIA,
INTERNATIONAL COURIER SERVICES ALGERIA,
INTERNATIONAL COURIER SERVICES AMERICAN SAMOA,
INTERNATIONAL COURIER SERVICES ANDORRA,
INTERNATIONAL COURIER SERVICES ANGOLA,
INTERNATIONAL COURIER SERVICES ANGUILLA,
INTERNATIONAL COURIER SERVICES ANTIGUA,
INTERNATIONAL COURIER SERVICES ARGENTINA,
INTERNATIONAL COURIER SERVICES ARMENIA,
INTERNATIONAL COURIER SERVICES ARUBA,
INTERNATIONAL COURIER SERVICES AUSTRALIA ,
INTERNATIONAL COURIER SERVICES AUSTRIA,
INTERNATIONAL COURIER SERVICES AZERBAIJAN,
INTERNATIONAL COURIER SERVICES BAHAMAS,
INTERNATIONAL COURIER SERVICES BAHRAIN,
INTERNATIONAL COURIER SERVICES BANGLADESH,
INTERNATIONAL COURIER SERVICES BARBADOS,
INTERNATIONAL COURIER SERVICES BELARUS,
INTERNATIONAL COURIER SERVICES BELGIUM,
INTERNATIONAL COURIER SERVICES BELIZE,
INTERNATIONAL COURIER SERVICES BENIN ,
INTERNATIONAL COURIER SERVICES BERMUDA,
INTERNATIONAL COURIER SERVICES BHUTAN,
INTERNATIONAL COURIER SERVICES BOLIVIA,
INTERNATIONAL COURIER SERVICES BONAIRE,
INTERNATIONAL COURIER SERVICES BOSNIA & HERZEGOVINA,
INTERNATIONAL COURIER SERVICES BOTSWANA,
INTERNATIONAL COURIER SERVICES BRAZIL,
INTERNATIONAL COURIER SERVICES BRUNEI,
INTERNATIONAL COURIER SERVICES BULGARIA,
INTERNATIONAL COURIER SERVICES BURKINA FASO,
INTERNATIONAL COURIER SERVICES BURUNDI,
INTERNATIONAL COURIER SERVICES CAMBODIA,
INTERNATIONAL COURIER SERVICES CAMEROON,
INTERNATIONAL COURIER SERVICES CANADA,
INTERNATIONAL COURIER SERVICES CANARY ISLANDS, THE,
INTERNATIONAL COURIER SERVICES CAPE VERDE,
INTERNATIONAL COURIER SERVICES CAYMAN ISLANDS,
INTERNATIONAL COURIER SERVICES CENTRAL AFRICAN REP,
INTERNATIONAL COURIER SERVICES CHAD,
INTERNATIONAL COURIER SERVICES CHILE,
INTERNATIONAL COURIER SERVICES CHINA,
INTERNATIONAL COURIER SERVICES ECUADOR,
INTERNATIONAL COURIER SERVICES EGYPT,
INTERNATIONAL COURIER SERVICES EL SALVADOR,
INTERNATIONAL COURIER SERVICES ERITREA,
INTERNATIONAL COURIER SERVICES ESTONIA,
INTERNATIONAL COURIER SERVICES ESWATINI,
INTERNATIONAL COURIER SERVICES ETHIOPIA,
INTERNATIONAL COURIER SERVICES FALKLAND ISLANDS,
INTERNATIONAL COURIER SERVICES FAROE ISLANDS,
INTERNATIONAL COURIER SERVICES FIJI,
INTERNATIONAL COURIER SERVICES FINLAND,
INTERNATIONAL COURIER SERVICES FRANCE,
INTERNATIONAL COURIER SERVICES FRENCH GUYANA,
INTERNATIONAL COURIER SERVICES GABON,
INTERNATIONAL COURIER SERVICES GAMBIA,
INTERNATIONAL COURIER SERVICES GEORGIA,
INTERNATIONAL COURIER SERVICES GERMANY,
INTERNATIONAL COURIER SERVICES GHANA,
INTERNATIONAL COURIER SERVICES GIBRALTAR,
INTERNATIONAL COURIER SERVICES GREECE,
INTERNATIONAL COURIER SERVICES GREENLAND,
INTERNATIONAL COURIER SERVICES GRENADA,
INTERNATIONAL COURIER SERVICES GUADELOUPE,
INTERNATIONAL COURIER SERVICES GUAM,
INTERNATIONAL COURIER SERVICES GUATEMALA,
INTERNATIONAL COURIER SERVICES GUERNSEY,
INTERNATIONAL COURIER SERVICES GUINEA REP.,
INTERNATIONAL COURIER SERVICES GUINEA-BISSAI,
INTERNATIONAL COURIER SERVICES GUINEA-EQUATORIAL,
INTERNATIONAL COURIER SERVICES GUYANA (BRITISH),
INTERNATIONAL COURIER SERVICES HAITI,
INTERNATIONAL COURIER SERVICES HONDURAS,
INTERNATIONAL COURIER SERVICES HONG KONG SAR CHINA,
INTERNATIONAL COURIER SERVICES HUNGARY,
INTERNATIONAL COURIER SERVICES ICELAND,
INTERNATIONAL COURIER SERVICES INDONESIA,
INTERNATIONAL COURIER SERVICES IRAN,
INTERNATIONAL COURIER SERVICES IRAQ,
INTERNATIONAL COURIER SERVICES IRELAND, 
REP.OF INTERNATIONAL COURIER SERVICES ISRAEL,
INTERNATIONAL COURIER SERVICES ITALY,
INTERNATIONAL COURIER SERVICES JAMAICA,
INTERNATIONAL COURIER SERVICES JAPAN,
INTERNATIONAL COURIER SERVICES COLOMBIA,
INTERNATIONAL COURIER SERVICES COMOROS,
INTERNATIONAL COURIER SERVICES CONGO,
INTERNATIONAL COURIER SERVICES CONGO, DPR,
INTERNATIONAL COURIER SERVICES COOK ISLANDS,
INTERNATIONAL COURIER SERVICES COSTA RICA,
INTERNATIONAL COURIER SERVICES COTE D IVOIRE,
INTERNATIONAL COURIER SERVICES CROATIA,
INTERNATIONAL COURIER SERVICES CUBA,
INTERNATIONAL COURIER SERVICES CURACAO,
INTERNATIONAL COURIER SERVICES CYPRUS,
INTERNATIONAL COURIER SERVICES CZECH REP., 
THE INTERNATIONAL COURIER SERVICES DENMARK,
INTERNATIONAL COURIER SERVICES DJIBOUTI,
INTERNATIONAL COURIER SERVICES DOMINICA,
INTERNATIONAL COURIER SERVICES DOMINICAN REP.,
INTERNATIONAL COURIER SERVICES JERSEY,
INTERNATIONAL COURIER SERVICES JORDAN,
INTERNATIONAL COURIER SERVICES KAZAKHSTAN,
INTERNATIONAL COURIER SERVICES KENYA,
INTERNATIONAL COURIER SERVICES KIRIBATI,
INTERNATIONAL COURIER SERVICES KOREA, 
REP. OF INTERNATIONAL COURIER SERVICES KOREA, 
D.P.R OF INTERNATIONAL COURIER SERVICES KOSOVO,
INTERNATIONAL COURIER SERVICES KUWAIT,
INTERNATIONAL COURIER SERVICES KYRGYZSTAN,
INTERNATIONAL COURIER SERVICES LAOS,
INTERNATIONAL COURIER SERVICES LATVIA,
INTERNATIONAL COURIER SERVICES LEBANON,
INTERNATIONAL COURIER SERVICES LESOTHO,
INTERNATIONAL COURIER SERVICES LIBERIA,
INTERNATIONAL COURIER SERVICES LIBYA,
INTERNATIONAL COURIER SERVICES LIECHTENSTEIN,
INTERNATIONAL COURIER SERVICES LITHUANIA,
INTERNATIONAL COURIER SERVICES LUXEMBOURG,
INTERNATIONAL COURIER SERVICES MACAU SAR CHINA,
INTERNATIONAL COURIER SERVICES MADAGASCAR,
INTERNATIONAL COURIER SERVICES MALAWI, 
INTERNATIONAL COURIER SERVICES MALAYSIA,
INTERNATIONAL COURIER SERVICES MALDIVES,
INTERNATIONAL COURIER SERVICES MALI,
INTERNATIONAL COURIER SERVICES MALTA,
INTERNATIONAL COURIER SERVICES MARIANA ISLANDS ,
INTERNATIONAL COURIER SERVICES MARSHALL ISLANDS,
INTERNATIONAL COURIER SERVICES MARTINIQUE,
INTERNATIONAL COURIER SERVICES MAURITANIA,
INTERNATIONAL COURIER SERVICES MAURITIUS,
INTERNATIONAL COURIER SERVICES MAYOTTE,
INTERNATIONAL COURIER SERVICES MEXICO,
INTERNATIONAL COURIER SERVICES MICRONESIA,
INTERNATIONAL COURIER SERVICES MOLDOVA, 
EP. OF INTERNATIONAL COURIER SERVICES MONACO,
INTERNATIONAL COURIER SERVICES MANGOLIA,
INTERNATIONAL COURIER SERVICES MONTENEGRO, 
REP OF INTERNATIONAL COURIER SERVICES MONTSERRAT,
INTERNATIONAL COURIER SERVICES MOROCCO,
INTERNATIONAL COURIER SERVICES MOZAMBIQUE,
INTERNATIONAL COURIER SERVICES MYANMAR,
INTERNATIONAL COURIER SERVICES NAMIBIA,
INTERNATIONAL COURIER SERVICES NAURU, 
REP. OF INTERNATIONAL COURIER SERVICES NEPAL,
INTERNATIONAL COURIER SERVICES NETHERLANDS,
THE INTERNATIONAL COURIER SERVICES NEVIS,
INTERNATIONAL COURIER SERVICES NEW CALEDONIA,
INTERNATIONAL COURIER SERVICES NEW ZEALAND,
INTERNATIONAL COURIER SERVICES NICARAGUA,
INTERNATIONAL COURIER SERVICES NIGER,
INTERNATIONAL COURIER SERVICES NIGERIA,
INTERNATIONAL COURIER SERVICES NIUE,
INTERNATIONAL COURIER SERVICES NORTH MACEDONIA
INTERNATIONAL COURIER SERVICES NORWAY,
INTERNATIONAL COURIER SERVICES OMAN,
INTERNATIONAL COURIER SERVICES PAKISTAN,
INTERNATIONAL COURIER SERVICES PALAU,
INTERNATIONAL COURIER SERVICES SAN MARINO,
INTERNATIONAL COURIER SERVICES SAO TOME AND PRINCIPE,
INTERNATIONAL COURIER SERVICES SAUDI ARABIA,
INTERNATIONAL COURIER SERVICES SENEGAL,
INTERNATIONAL COURIER SERVICES SERBIA, 
REP OF INTERNATIONAL COURIER SERVICES SEYCHELLES,
INTERNATIONAL COURIER SERVICES SIERRA LEONE,
INTERNATIONAL COURIER SERVICES SINGAPORE,
INTERNATIONAL COURIER SERVICES SLOVAKIA,
INTERNATIONAL COURIER SERVICES SLOVENIA,
INTERNATIONAL COURIER SERVICES SOLOMON ISLANDS,
INTERNATIONAL COURIER SERVICES SOMALIA,
INTERNATIONAL COURIER SERVICES SOMALILAND, 
REP OF INTERNATIONAL COURIER SERVICES SOUTH AFRICA,
INTERNATIONAL COURIER SERVICES SOUTH SUDAN,
INTERNATIONAL COURIER SERVICES SPAIN,
INTERNATIONAL COURIER SERVICES SRI LANKA,
INTERNATIONAL COURIER SERVICES ST. BARTHELEMY,
INTERNATIONAL COURIER SERVICES ST. EUSTATIUS,
INTERNATIONAL COURIER SERVICES ST. KITTS,
INTERNATIONAL COURIER SERVICES ST. LUCIA,
INTERNATIONAL COURIER SERVICES ST. MAARTEN,
INTERNATIONAL COURIER SERVICES ST. VINCENT,
INTERNATIONAL COURIER SERVICES SUDAN,
INTERNATIONAL COURIER SERVICES SURINAME,
INTERNATIONAL COURIER SERVICES SWEDEN,
INTERNATIONAL COURIER SERVICES SWITZERLAND,
INTERNATIONAL COURIER SERVICES SYRIA,
INTERNATIONAL COURIER SERVICES TAHITI,
INTERNATIONAL COURIER SERVICES TAIWAN,
INTERNATIONAL COURIER SERVICES TAJIKISTAN,
INTERNATIONAL COURIER SERVICES TANZANIA,
INTERNATIONAL COURIER SERVICES THAILAND,
INTERNATIONAL COURIER SERVICES TIMOR-LESTE,
INTERNATIONAL COURIER SERVICES TOGO,
INTERNATIONAL COURIER SERVICES TONGA,
INTERNATIONAL COURIER SERVICES TRINIDAD AND TOBAGO,
INTERNATIONAL COURIER SERVICES TUNISIA,
INTERNATIONAL COURIER SERVICES TURKEY,
INTERNATIONAL COURIER SERVICES TURKMENISTAN,
INTERNATIONAL COURIER SERVICES TURKS & CAICOS,
INTERNATIONAL COURIER SERVICES TUVALU,
INTERNATIONAL COURIER SERVICES U S A,
INTERNATIONAL COURIER SERVICES PANAMA,
INTERNATIONAL COURIER SERVICES PAPUA NEW GUINEA,
INTERNATIONAL COURIER SERVICES PARAGUAY,
INTERNATIONAL COURIER SERVICES PERU,
INTERNATIONAL COURIER SERVICES PHILIPPINES,
THE INTERNATIONAL COURIER SERVICES POLAND,
INTERNATIONAL COURIER SERVICES PORTUGAL,
INTERNATIONAL COURIER SERVICES PUERTO RICO,
INTERNATIONAL COURIER SERVICES QATAR,
INTERNATIONAL COURIER SERVICES REUNION, 
ISLAND OF INTERNATIONAL COURIER SERVICES ROMANIA,
INTERNATIONAL COURIER SERVICES RUSSIAN FEDERATION,
INTERNATIONAL COURIER SERVICES RWANDA,
INTERNATIONAL COURIER SERVICES SAINT HELENA ,
INTERNATIONAL COURIER SERVICES SAMOA,
INTERNATIONAL COURIER SERVICES UGANDA,
INTERNATIONAL COURIER SERVICES UKRAINE,
INTERNATIONAL COURIER SERVICES UNITED ARAB EMIRATES,
INTERNATIONAL COURIER SERVICES UNITED KINGDOM,
INTERNATIONAL COURIER SERVICES URUGUAY,
INTERNATIONAL COURIER SERVICES UZBEKISTAN,
INTERNATIONAL COURIER SERVICES VANUATU,
INTERNATIONAL COURIER SERVICES VATICAN CITY,
INTERNATIONAL COURIER SERVICES VENEZUELA,
INTERNATIONAL COURIER SERVICES VIETNAM,
INTERNATIONAL COURIER SERVICES VIRGIN ISLANDS-BRITISH ,
INTERNATIONAL COURIER SERVICES VIRGIN ISLANDS-US,
INTERNATIONAL COURIER SERVICES YEMEN,
REP. OF INTERNATIONAL COURIER SERVICES ZAMBIA,
INTERNATIONAL COURIER SERVICES ZIMBABWE,
">

        
         
 
 
 
 



 



        <meta property="og:type" content="website">
        <meta property="og:image" content="https://www.expresscok.com/uploads/media_library/26112009_1971299232887217_4659631034525653846_n6.jpg">
        <meta property="og:title" content="DHL EXPRESS INTERNATIONAL COURIER & CARGO SERVICE">
        <meta property="og:description" content="DHL FEDEX TNT UPS ARAMEX FLAT 35 % DISCOUNTS FOR EUROPE, USA, AUSTRALIA, NEW ZEALAND, CHINA SHIPMENTS, REST OF THE COUNTRIES 30% DISCOUNT, CALL 7403005001">
        <meta property="og:site_name" content="Ex Courier india Private Limited">
        <meta property="og:url" content="https://www.expresscok.com/">

        <link href="<?php echo resource('frontend')?>images/favicon.png" type="images/png" rel="shortcut icon" />
        <link media="none" onload="if(media!='all')media='all'" href="<?php echo resource('frontend')?>css/css.localhomepageTemp.homepage.css?v=1" rel="stylesheet" type="text/css"/>
        <style>
            #content_cross_reference {
                width: 24em;
            }
        </style>
        <link href="<?php echo resource('frontend')?>css/facelift.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo resource('frontend')?>css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- Custom Theme files -->
        <link rel="stylesheet" href="<?php echo resource('frontend')?>css/menu.css" />
        <link href="<?php echo resource('frontend')?>css/style.css" rel="stylesheet" type="text/css" media="all" />
        <!-- Custom Theme files -->
        <script src="<?php echo resource('frontend')?>js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/jquery-migrate-1.2.1.min.js"></script>
        <script src="<?php echo resource('frontend')?>js/bootstrap.min.js"></script>
        <!-- Custom Theme files -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!--webfont-->
        <link href='https://fonts.googleapis.com/css?family=Oxygen:400,700,300' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <!-- start menu -->
        <link href="<?php echo resource('frontend')?>css/megamenu.html" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/megamenu.js"></script>
        <script>$(document).ready(function () {
                $(".megamenu").megamenu();
            });</script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/jquery.leanModal.min.js"></script>
        <link rel="stylesheet" href="<?php echo resource('frontend')?>css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo resource('frontend')?>css/magnific-popup.css" />
        <script src="<?php echo resource('frontend')?>js/easyResponsiveTabs.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#horizontalTab').easyResponsiveTabs({
                    type: 'default', //Types: default, vertical, accordion           
                    width: 'auto', //auto or any width like 600px
                    fit: true   // 100% fit in a container
                });
            });
        </script>
        <script type="text/javascript">
            function login() {
                alert('Invalid User');
            }
        </script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/move-top.js"></script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/easing.min.js"></script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/jquery.magnific-popup.min.js"></script>
        <script type="text/javascript">
            function setCookie(cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires="+d.toUTCString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
            }

            function getCookie(cname) {
                var name = cname + "=";
                var ca = document.cookie.split(';');
                for(var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        return c.substring(name.length, c.length);
                    }
                }
                return "";
            }

            function checkCookie() {
                
            }
            jQuery(document).ready(function ($) {
                $(".scroll").click(function (event) {
                    event.preventDefault();
                    $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1200);
                });
                $('.popup-modal').magnificPopup({
                    type: 'inline',
                    preloader: false,
                    focus: '#username',
                    modal: true
                });
                $(document).on('click', '.popup-modal-dismiss', function (e) {
                    e.preventDefault();
                    $.magnificPopup.close();
                });
                $('.home-popup-close').click(function(){
                    setCookie('warningclosed', 'closed', 1);
                    $('.home-popup-content').removeClass('show_warning');
                });

                var user = getCookie("warningclosed");
                if (user != "") {
                    
                } else {
                    $('.home-popup-content').addClass('show_warning');
                }

            });
        </script>
        <!---- start-smoth-scrolling---->
        <script>
$(document).ready(function(){
    $("#hide").click(function(){
        $(".trackdetails").hide();
    });
    $("#show").click(function(){
        $(".trackdetails").show();
    });
});
</script>
<script type="text/javascript">
function show(){
    $("#show").css("display", "block");
}
function hide(){
    $("#show").css("display", "none");
}
</script>
<style>
                            .dropdown ul li:hover a{background: #FFCC00; /* For browsers that do not support gradients */
    background: -webkit-linear-gradient(#FFCC00, #CA0000)!important; /* For Safari 5.1 to 6.0 */
    background: -o-linear-gradient(#FFCC00, #CA0000)!important; /* For Opera 11.1 to 12.0 */
    background: -moz-linear-gradient(#FFCC00, #CA0000)!important; /* For Firefox 3.6 to 15 */
    background: linear-gradient(#FFCC00, #CA0000)!important;}
                            </style>
                            


<!-- Global site tag (gtag.js) - Google AdWords: 813871064 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-813871064"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-813871064');
</script>



<script>
  window.addEventListener('load',function(){
    if(jQuery('.error-success:contains("Your message has been successfully submitted.")').is(":visible")){
      gtag('event', 'conversion', {'send_to': 'AW-813871064/9cSyCM_1v4ABENjfioQD'});
    }
  })
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-136936369-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-136936369-1');
</script>

<?php if ($active=="contact"){ ?> 
<script>
  gtag('event', 'conversion', {'send_to': 'AW-617329268/1BEFCM3q6eEBEPTkrqYC'});
</script>
<?php } ?>

    </head>
    <body>

        <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.0';
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
         
        <div class="container">
            <div class="main-content">
                <div class="header" itemscope itemtype="http://schema.org/Service">
                    <div class="logo" id="home">
                        <a itemprop="url" href="<?php echo base_url();?>"><img src="<?php echo resource('frontend')?>images/logo.png" alt="Express International COURIER & CARGO SERVICE" itemprop="image" /></a>
                        <span itemprop="name" class="hide_this">Express International COURIER & CARGO SERVICE</span>
                        <span class="trademark header">&trade;</span>
                    </div>
                    <div class="search">
                        <div class="search2">
                            <img class="myw-search-img" src="<?php echo resource('frontend')?>images/iso.png" alt="courier" />
                             
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="bootstrap_container">
                    <nav class="navbar navbar-default w3_megamenu" role="navigation">
                        <div class="mob-contact-sec" style="margin-left: 21px; position: absolute;">
                            <ul>
                                <li style="display:inline-block;"> <i class="fa fa-phone"></i><a href="tel:00917403005001">00917403005001</a></li>
                                 <li style="display:inline-block;"> <i class="fa fa-phone"></i><a href="tel:00914844000071"> 00914844000071</a> </li>
                            </ul>
                            
                             </div>
                        <div class="navbar-header">
                            <button type="button" data-toggle="collapse" data-target="#defaultmenu" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                            <!--<a href="#" class="navbar-brand"><i class="fa fa-home" style="color: #CA0000;"></i></a>-->
                        </div><!-- end navbar-header -->

                        <div id="defaultmenu" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li <?php if ($active=="home"){ ?> class="active" <?php } ?>><a href="<?php echo base_url();?>">Home</a></li>	
                                <li <?php if ($active=="about"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('about');?>">About Us</a></li>	
                                <li class="dropdown <?php if ($active=="services"){ ?> active <?php } ?>"><a data-toggle="dropdown" class="dropdown-toggle">Services<b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?php echo base_url('international');?>">International Document Delivery Services</a></li>
                                        <li><a href="<?php echo base_url('parcel');?>">Parcel Delivery Services</a></li>
                                        <li><a href="<?php echo base_url('food');?>">Food Items Delivery</a></li>
                                        <li><a href="<?php echo base_url('cargo');?>">Cargo Services</a></li>
                                        <li><a href="<?php echo base_url('baggage');?>">Excess Baggage & Unaccompanied Baggage Delivery</a></li>
                                        <li><a href="<?php echo base_url('medicine');?>">Medicine Delivery</a></li>
                                        <li><a href="<?php echo base_url('warehousing');?>">Warehousing & Distribution</a></li>
                                        <li><a href="<?php echo base_url('airsea');?>">Air Freight and Sea Cargo</a></li>
                                    </ul>
                                </li>
                                <li <?php if ($active=="tracking"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('tracking');?>">Live Tracking</a></li>	
                               
                               <li <?php if ($active=="tools"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('tools');?>">Tools</a></li>
                               
                                <li <?php if ($active=="documents"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('documents');?>">Documents</a></li>	
                                <li <?php if ($active=="contact"){ ?>  class="active" <?php } ?>><a href="<?php echo base_url('contact');?>">Contact Us</a></li>
                            </ul><!-- end nav navbar-nav -->


                            <!--	<ul class="nav navbar-nav navbar-right">
                                            <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Pickup Request<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <form id="contact1" action="#" name="contactform" method="post">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                            <input type="text" name="name" id="name1" class="form-control" placeholder="Name"> 
                                            <input type="text" name="email" id="Text1" class="form-control" placeholder="Email"> 
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                            <input type="text" name="phone" id="phone1" class="form-control" placeholder="Phone">
                                            <input type="text" name="subject" id="subject1" class="form-control" placeholder="Subject"> 
                                        </div>                 
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <textarea class="form-control" name="comments" id="comments1" rows="6" placeholder="Your Message ..."></textarea>
                                        </div>   
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="pull-right">
                                                <input type="submit" value="SEND" id="submit1" class="btn btn-primary small">
                                            </div>  
                                        </div>
                                                                            <div class="clearfix"></div>  
                                    </form>
                                </li>
                            </ul>
                                            </li>
                                    </ul> end nav navbar-nav navbar-right -->

                            <div class="myw-telephone-header">
                                <p class="row1"><i class="fa fa-phone"></i><a> 0484-4000071</a>  </p>
                                <p class="row2"><i class="fa fa-envelope"></i><a> care@expresscok.com</a>  </p>
                            </div>
                        </div><!-- end #navbar-collapse-1 -->
                    </nav><!-- end navbar navbar-default w3_megamenu -->
                </div><!-- end container -->

                <div class="home-popup-content" style="display:none"> 
                    <a href="javascript:void(0)" class="home-popup-close">
                        <img src="<?php echo resource('frontend')?>images/home-popup-close.png">
                    </a>
                    <div class="row warning-header">
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <h1>FRAUDULENT ALERT</h1>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <img class="logo-warning" src="<?php echo resource('frontend')?>images/warning-logo.png" alt="Expresscok"/>
                            <span class="trademark popup">&trade;</span>
                        </div>
                    </div>                                                       
                    <p>Unauthorized use of its business names, service marks and logos by persons or companies fraudulently representing themselves as EX Courier India Private Limited - Express International or as representatives of EX Courier India Private Limited - Express International </p> 
                    <a target="_blank" href="#test-modal" class="popup-modal call-action white-hover">Click for More Details</a>                    
                </div>

                <div id="test-modal" class="white-popup-block mfp-hide">
                    <p><b>Unauthorized use of EX Courier India Private Limited - Express International � Business Names, Service Marks and Logos</b>
EX Courier India Private Limited - Express International has been alerted to the unauthorized use of its business names, service marks and logos by persons or companies fraudulently representing themselves as EX Courier India Private Limited - Express International or as representatives of EX Courier India Private Limited - Express International.</p>
<p>Millions of fraudulent e-mails and sms messages are deployed daily. They claim to come from a wide variety of sources, and some claim to be from EX Courier India Private Limited - Express International or representing EX Courier India Private Limited - Express International. Fraudulent e-mail and sms messages, often referred to as "phishing" or brand "spoofing," are becoming increasingly common. These types of messages often use corporate logos, colors and legal disclaimers to make it appear as though they are real. They are sent in an attempt to trick people into sending money and providing personal information such as usernames, passwords and/or credit card details, and for the purpose of committing theft, identity theft and/or other crimes.</p>

<p>
    <h4>Recognizing Phishing Scam E-mails and sms messages</h4>
recognizing phishing scam e-mails and sms messages is key to protecting yourself against such theft and other crimes. Indicators that an e-mail or sms message might be fraudulent include:
   <ul>
    <li>Unexpected requests for money in return for delivery of a package or other item, personal and/or financial information, such as your Social Security number, bank account number, or other identification.</li>
    <li>Links to misspelled or slightly altered Web-site addresses. For example, variations on the correct Web-site address EX Courier India Private Limited - Express International .com, such as <a href="https://www.expresscok.com">www.expresscok.com</a> excourier.com</li>
    <li>Alarming messages and requests for immediate action, such as "Your account will be suspended within 24 hours if you don't respond" or claims that you've won the lottery or a prize.</li>
    <li>Spelling and grammatical errors and excessive use of exclamation points (!).</li>
</ul> 
</p>


<p>EX Courier India Private Limited - Express International does not request, via unsolicited mail, e-mail or sms messages, payment or personal information in return for goods in transit or in EX Courier India Private Limited - Express International custody. If you have received a fraudulent e-mail or sms message that claims to be from EX Courier India Private Limited - Express International , you can report it by forwarding it to <a href="mailto:info@expresscok.com">info@expresscok.com</a></p>

<p>If you have any questions or concerns about services provided by EX Courier India Private Limited - Express International , please review our services at <a href="mailto:info@expresscok.com">info@expresscok.com</a>  or contact Express customer service 0484 4000071
The Internet is an important channel connecting EX Courier India Private Limited - Express International  to its customers. While there is no foolproof method to prevent the unauthorized use of the EX Courier India Private Limited - Express International name, we continuously watch for such activity in order to help safeguard our customers' interests.</p>

<p>Thank you for helping us identifies and takes action against e-mail & sms fraud</p>

<hr>

<p> NOTE: EX Courier India Private Limited - Express International is not responsible for any charges or costs incurred as a result of fraudulent activity that abuses the EX Courier India Private Limited - Express International name, service marks and logos.</p>

<p>EX Courier India Private Limited - Express International does not require money transfers through third-party escrow services or online payment services prior to shipment delivery</p>

<p>The use of the EX Courier India Private Limited - Express International logo and name on these websites is unauthorized and our legal department will address this matter with the relevant authorities.</p>
<br/>
<p><a class="popup-modal-dismiss" href="#">CLOSE</a></p>
                </div>
