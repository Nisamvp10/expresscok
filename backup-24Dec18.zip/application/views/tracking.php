
<ol class="breadcrumb">
    <li><a href="<?php echo base_url();?>">Home</a></li> 
    <li class="active">Live Tracking</li>
</ol>

<div class="about-section" style="margin-bottom: 50px;">

    <div class="e-payment-section">
        <div class="col-md-8 col-sm-8 col-xs-12 payment-left">
            <div class="confirm-details">
                <h3 style="margin-bottom:10px;">Live Tracking</h3>
                <p style="text-align:justify;font-size: 0.95em;line-height: 1.8em;font-weight: 400;"><img src="<?php echo resource('frontend')?>images/pic-42.jpg" height="130px" style="float:left; margin-right:10px; margin-top:4px;" /> Our vehicles are installed with GPS tracking system to ensure the safety of vehicle, consignment and also will enable data like Latitude, Longitude, Speed Idle Time and running status of Vehicles to our application server. </p>
                <p>&nbsp;</p>
                <p style="text-align:justify;font-size: 0.95em;line-height: 1.8em;font-weight: 400;">This also helps us for scheduled operating of vehicles always connecting to the branches enroute and reporting movements to ensure prompt delivery. Moreover we provide Login credential to corporate companies to know the location of the vehicle.</p>

            </div>
            <div class="row" style="padding: 50px 0px;">
                <div class="col-md-2 col-sm-2 col-xs-12 track_links">
                    <a href="https://www.aramex.com/track/shipments/" target="_blank"><img class="img-responsive" src="<?php echo resource('frontend')?>images/logos/aramex.png" alt="Aramex" /></a>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12 track_links">
                    <a href="https://www.ups.com/WebTracking/track?loc=en_us" target="_blank"><img class="img-responsive" src="<?php echo resource('frontend')?>images/logos/UPS-Logo_250.png" alt="UPS" /></a>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12 track_links">
                    <a href="https://www.fedex.com/apps/fedextrack/?action=track" target="_blank"><img class="img-responsive" src="<?php echo resource('frontend')?>images/logos/fedex_logo_feature.png" alt="FedEx" /></a>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12 track_links">
                    <a href="https://www.expresscok.com/tracking"><img class="img-responsive" src="<?php echo resource('frontend')?>images/logos/logo.png" alt="DHL" /></a>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12 track_links">
                    <a href="https://www.bluedart.com/maintracking.html" target="_blank"><img class="img-responsive" src="<?php echo resource('frontend')?>images/logos/blue-dart-logo.png" alt="Bluedart" /></a>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12 track_links">
                    <a href="http://www.dtdc.in/tracking/shipment-tracking.asp" target="_blank"><img  class="img-responsive" src="<?php echo resource('frontend')?>images/logos/dtdc.png" alt="DTDC" /></a>
                </div>
            </div>

        </div>
        <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="col-md-12 col-sm-12 col-xs-12 right_panel">
            <div class="express_tab">Express</div>  
            <div class="col-md-12 col-sm-12 col-xs-12 track_div_arg">
                <h5 class="fa fa-minus-square" style="float: left;padding: 5px 0px 0px 10px;">&nbsp;Track Your Shipment</h5>
				<form enctype="multipart/form-data" method="post" action="track_order">
					<div id="reply">
					<?php $field_data=array();if($this->session->flashdata('error')){
						$field_data=$this->session->flashdata('value');
						echo $this->session->flashdata('error');
					 } ?>
					</div>
					<input  type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();  ?>"> 
                    <textarea placeholder="Enter tracking number(s)" name="track_id"></textarea>
					<input type="hidden" value="<?php echo current_url();?>" name="rurl" />
                    <button type="submit" >Track </button>
                    <h6>Track upto 10 numbers at a time. Separate with a comma (,) or return (enter).</h6>
                </form>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <a class="fa fa-arrow-right" style="float: left;">&nbsp;More Tracking Options</a><br>
                    <a href="/contact" class="fa fa-arrow-right" style="float: left;">&nbsp;Contact Express Courier</a>
                </div>
            </div>
        </div>
    </div>
        <div class="clearfix"></div>
    </div>
    <!--start-carrer-->
    <!----- Comman-js-files ----->
    <script>
        $(document).ready(function () {
            $("#tab2").hide();
            $("#tab3").hide();
            $("#tab4").hide();
            $(".tabs-menu a").click(function (event) {
                event.preventDefault();
                var tab = $(this).attr("href");
                $(".tab-grid").not(tab).css("display", "none");
                $(tab).fadeIn("slow");
            });
        });
    </script>
</div>

<p class="sed-para fa fa-phone"> Phone : </p>
            <p class="para1"> Call Now for any query 
            0484-4000071 </p>
            <p class="para1">  7403005001 </p>
            <p class="sed-para fa fa-envelope"> Email : </p>
            <p class="para1">  expresscok@gmail.com </p>