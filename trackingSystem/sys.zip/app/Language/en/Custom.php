<?php
return [
    'tryAgain' => 'Oops! Please try again later.',
    'invalidCredentials' => 'Invalid username or password.',
    'formError' => 'Please check the form and try again.',
    'accessDenied' => 'Opps Access Denied',
    'invalidRequest' => 'Invalid Request',
    'updateMsg'    => 'Updated Successfully'
];