<div class="footer-grid">
    <div class="clearfix"></div>			
</div>

</div>


<div class="clearfix"></div>
</div>
<div class="copy-rights text-center">
    <p class="myw-cpy-rht">
		<a href="<?php echo base_url();?>">Home</a> | 
		<a href="<?php echo base_url('about');?>">About Us</a> |
		<a href="<?php echo base_url('tracking');?>">Live Tracking</a> | 
		<a href="<?php echo base_url('documents');?>">Documents</a> | 
		<a href="<?php echo base_url('contact');?>">Contact Us</a> | 
		<a href="https://www.facebook.com/dhlexpresscok" target="_blank" class="social-icons-headarg"><i class="fa fa-facebook"></i></a>
        <a href="" target="_blank" class="social-icons-headarg"><i class="fa fa-twitter"></i></a>
        <a href="" target="_blank" class="social-icons-headarg"><i class="fa fa-linkedin"></i></a>
        <a href="" target="_blank" class="social-icons-headarg"><i class="fa fa-google-plus"></i></a>
    <!--</div>-->
	</p>
<p class="footer-left">Copyright &copy; 2018 | All Rights Reserved | 
    <a class="footer_express_logo" href="<?php echo base_url();?>">
        <img src="<?php echo resource('frontend')?>images/logos/express_footer.png" width="70" alt="Ex COURIER INDIA PRIVATE LIMITED- EXPRESS">
    </a>
    &trade;
</p>
    <div class="row footer-disclaimer">
        <div class="col-sm-8 col-xs-12"><p class="left">*Unauthorised use of this logo in any other websites will be procecuted and legal actions will be taken.</p></div>
        <div class="col-sm-4 col-xs-12"><p class="right">Ex COURIER INDIA PRIVATE LIMITED- EXPRESS </p></div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        /*
         var defaults = {
         containerID: 'toTop', // fading element id
         containerHoverID: 'toTopHover', // fading element hover id
         scrollSpeed: 1200,
         easingType: 'linear' 
         };
         */

        $().UItoTop({easingType: 'easeOutQuart'});

    });
</script>
<a href="#home" class="scroll" id="toTop"> <span id="toTopHover"> </span></a>
</body>

<!-- Mirrored from www.ssptlogistics.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 20 May 2017 09:59:38 GMT -->
</html>
