

<!DOCTYPE html>

<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <?php if(isset($tittle)&&!empty($tittle)){ ?>
        <title><?php echo $tittle; ?></title>
        <?php }  else { ?>
        <title>DHL EXPRESS INTERNATIONAL COURIER & CARGO SERVICE</title>
        <?php } ?>

        <?php
        if (isset($meta_description) && !empty($meta_description)) {
            ?>
            <meta name="description" content="<?php echo $meta_description?>"> 
            <?php
        } else {
            ?>
             <!--<meta name="description" content="Express International COURIER & CARGO SERVICE is the global market leader in the logistics industry. DHL commits its expertise in international parcel, express, air and ocean freight, road and rail transportation, contract logistics and international mail services to its customers."> -->             
             <meta name="description" content="DHL FEDEX TNT UPS ARAMEX FLAT 35 % DISCOUNTS FOR EUROPE ,USA , AUSTRALIA , NEW ZEALAND , CHINA SHIPMENTS, REST OF THE COUNTRIES 30% DISCOUNT , BOOK NOW CALL 7403005001 DHL FEDEX TNT UPS ARAMEX FLAT 35 % DISCOUNTS FOR EUROPE ,USA , AUSTRALIA , NEW ZEALAND , CHINA SHIPMENTS, REST OF THE COUNTRIES 30% DISCOUNT , BOOK NOW CALL 7403005001 International Courier Service in Kochi, Cargo Service in Kochi DHL Courier Service in Kochi, Domestic Courier Service in Kochi, Cargo Agents in Kochi, Air Cargo service in Kochi, 24 hours Courier Service in Kochi, Shipping Agents in Kochi, Domestic Cargo Agents in Kochi, Freight Forwarding Agents in Kochi,Domestic Courier Services In Kochi,Courier Services In Kochi,International Courier Services In Kochi,Cargo Agents In Kochi,International Cargo Agents In Kochi,Domestic Courier Services Aramex In Kochi,Courier Services For International DTDC In Kochi,Air Cargo Agents In Kochi,International Courier Services First Flight In Kochi,Domestic Air Cargo Agents In Kochi,DHL International Courier Services in Kochi,International Air Cargo Agents In Kochi,Aramex International Courier Services In Kochi,Sea Cargo Agents in Kochi, UPS International Courier Services In Kochi,Overnite Express International Courier Services in Kochi,DHL Cargo Agents In Kochi,TNT International Courier Services In Kochi,International Courier Services For Food Products In Kochi,Trackon International Courier Services In Kochi,Door To Door Domestic Courier Services In Kochi,Cargo Agents In Ernakulam,Cargo Agents For Sea International In Kochi,International Courier Services In Ernakulam,DHL Courier Services In Kochi,International Courier Services For Household Items In Kochi,International Bulk Courier Services In Kochi">
            <?php
        }

       
        ?>

        <link href="<?php echo resource('frontend')?>images/favicon.png" type="images/png" rel="shortcut icon" />
        <link media="none" onload="if(media!='all')media='all'" href="<?php echo resource('frontend')?>css/css.localhomepageTemp.homepage.css" rel="stylesheet" type="text/css"/>
        <style>
            #content_cross_reference {
                width: 24em;
            }
        </style>
        <link href="<?php echo resource('frontend')?>css/facelift.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo resource('frontend')?>css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- Custom Theme files -->
        <link rel="stylesheet" href="<?php echo resource('frontend')?>css/menu.css" />
        <link href="<?php echo resource('frontend')?>css/style.css" rel="stylesheet" type="text/css" media="all" />
        <!-- Custom Theme files -->
        <script src="<?php echo resource('frontend')?>js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/jquery-migrate-1.2.1.min.js"></script>
        <script src="<?php echo resource('frontend')?>js/bootstrap.min.js"></script>
        <!-- Custom Theme files -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!--webfont-->
        <link href='https://fonts.googleapis.com/css?family=Oxygen:400,700,300' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <!-- start menu -->
        <link href="<?php echo resource('frontend')?>css/megamenu.html" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/megamenu.js"></script>
        <script>$(document).ready(function () {
                $(".megamenu").megamenu();
            });</script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/jquery.leanModal.min.js"></script>
        <link rel="stylesheet" href="<?php echo resource('frontend')?>css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo resource('frontend')?>css/magnific-popup.css" />
        <script src="<?php echo resource('frontend')?>js/easyResponsiveTabs.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#horizontalTab').easyResponsiveTabs({
                    type: 'default', //Types: default, vertical, accordion           
                    width: 'auto', //auto or any width like 600px
                    fit: true   // 100% fit in a container
                });
            });
        </script>
        <script type="text/javascript">
            function login() {
                alert('Invalid User');
            }
        </script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/move-top.js"></script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/easing.min.js"></script>
        <script type="text/javascript" src="<?php echo resource('frontend')?>js/jquery.magnific-popup.min.js"></script>
        <script type="text/javascript">
            function setCookie(cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires="+d.toUTCString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
            }

            function getCookie(cname) {
                var name = cname + "=";
                var ca = document.cookie.split(';');
                for(var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        return c.substring(name.length, c.length);
                    }
                }
                return "";
            }

            function checkCookie() {
                
            }
            jQuery(document).ready(function ($) {
                $(".scroll").click(function (event) {
                    event.preventDefault();
                    $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1200);
                });
                $('.popup-modal').magnificPopup({
                    type: 'inline',
                    preloader: false,
                    focus: '#username',
                    modal: true
                });
                $(document).on('click', '.popup-modal-dismiss', function (e) {
                    e.preventDefault();
                    $.magnificPopup.close();
                });
                $('.home-popup-close').click(function(){
                    setCookie('warningclosed', 'closed', 1);
                    $('.home-popup-content').removeClass('show_warning');
                });

                var user = getCookie("warningclosed");
                if (user != "") {
                    
                } else {
                    $('.home-popup-content').addClass('show_warning');
                }

            });
        </script>
        <!---- start-smoth-scrolling---->
        <script>
$(document).ready(function(){
    $("#hide").click(function(){
        $(".trackdetails").hide();
    });
    $("#show").click(function(){
        $(".trackdetails").show();
    });
});
</script>
<script type="text/javascript">
function show(){
    $("#show").css("display", "block");
}
function hide(){
    $("#show").css("display", "none");
}
</script>
<style>
                            .dropdown ul li:hover a{background: #FFCC00; /* For browsers that do not support gradients */
    background: -webkit-linear-gradient(#FFCC00, #CA0000)!important; /* For Safari 5.1 to 6.0 */
    background: -o-linear-gradient(#FFCC00, #CA0000)!important; /* For Opera 11.1 to 12.0 */
    background: -moz-linear-gradient(#FFCC00, #CA0000)!important; /* For Firefox 3.6 to 15 */
    background: linear-gradient(#FFCC00, #CA0000)!important;}
                            </style>
                            


<!-- Global site tag (gtag.js) - Google AdWords: 813871064 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-813871064"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-813871064');
</script>



<script>
  window.addEventListener('load',function(){
    if(jQuery('.error-success:contains("Your message has been successfully submitted.")').is(":visible")){
      gtag('event', 'conversion', {'send_to': 'AW-813871064/9cSyCM_1v4ABENjfioQD'});
    }
  })
</script>
    </head>
    <body>

        <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.0';
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
         
        <div class="container">
            <div class="main-content">
                <div class="header" itemscope itemtype="http://schema.org/Service">
                    <div class="logo" id="home">
                        <a itemprop="url" href="<?php echo base_url();?>"><img src="<?php echo resource('frontend')?>images/logo.png" alt="Express International COURIER & CARGO SERVICE" itemprop="image" /></a>
                        <span itemprop="name" class="hide_this">Express International COURIER & CARGO SERVICE</span>
                        <span class="trademark header">&trade;</span>
                    </div>
                    <div class="search">
                        <div class="search2">
                            <img class="myw-search-img" src="<?php echo resource('frontend')?>images/iso.png" alt="courier" />
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="bootstrap_container">
                    <nav class="navbar navbar-default w3_megamenu" role="navigation">
                        <div class="navbar-header">
                            <button type="button" data-toggle="collapse" data-target="#defaultmenu" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                            <!--<a href="#" class="navbar-brand"><i class="fa fa-home" style="color: #CA0000;"></i></a>-->
                        </div><!-- end navbar-header -->

                        <div id="defaultmenu" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li <?php if ($active=="home"){ ?> class="active" <?php } ?>><a href="<?php echo base_url();?>">Home</a></li>	
                                <li <?php if ($active=="about"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('about');?>">About Us</a></li>	
                                <li class="dropdown <?php if ($active=="services"){ ?> active <?php } ?>"><a data-toggle="dropdown" class="dropdown-toggle">Services<b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?php echo base_url('international');?>">International Document Delivery Services</a></li>
                                        <li><a href="<?php echo base_url('parcel');?>">Parcel Delivery Services</a></li>
                                        <li><a href="<?php echo base_url('food');?>">Food Items Delivery</a></li>
                                        <li><a href="<?php echo base_url('cargo');?>">Cargo Services</a></li>
                                        <li><a href="<?php echo base_url('baggage');?>">Excess Baggage & Unaccompanied Baggage Delivery</a></li>
                                        <li><a href="<?php echo base_url('medicine');?>">Medicine Delivery</a></li>
                                        <li><a href="<?php echo base_url('warehousing');?>">Warehousing & Distribution</a></li>
                                        <li><a href="<?php echo base_url('airsea');?>">Air Freight and Sea Cargo</a></li>
                                    </ul>
                                </li>
                                <li <?php if ($active=="tracking"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('tracking');?>">Live Tracking</a></li>	
                               
                               <li <?php if ($active=="tools"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('tools');?>">Tools</a></li>
                               
                                <li <?php if ($active=="documents"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('documents');?>">Documents</a></li>	
                                <li <?php if ($active=="contact"){ ?> class="active" <?php } ?>><a href="<?php echo base_url('contact');?>">Contact Us</a></li>
                            </ul><!-- end nav navbar-nav -->


                            <!--	<ul class="nav navbar-nav navbar-right">
                                            <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Pickup Request<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <form id="contact1" action="#" name="contactform" method="post">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                            <input type="text" name="name" id="name1" class="form-control" placeholder="Name"> 
                                            <input type="text" name="email" id="Text1" class="form-control" placeholder="Email"> 
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                            <input type="text" name="phone" id="phone1" class="form-control" placeholder="Phone">
                                            <input type="text" name="subject" id="subject1" class="form-control" placeholder="Subject"> 
                                        </div>                 
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <textarea class="form-control" name="comments" id="comments1" rows="6" placeholder="Your Message ..."></textarea>
                                        </div>   
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="pull-right">
                                                <input type="submit" value="SEND" id="submit1" class="btn btn-primary small">
                                            </div>  
                                        </div>
                                                                            <div class="clearfix"></div>  
                                    </form>
                                </li>
                            </ul>
                                            </li>
                                    </ul> end nav navbar-nav navbar-right -->

                            <div class="myw-telephone-header">
                                <p class="row1"><i class="fa fa-phone"></i><a> 0484-4000071</a>  </p>
                                <p class="row2"><i class="fa fa-envelope"></i><a> exp<!-- >@ -->resscok<!-- >@ -->@<!-- >@ -->gmail<!-- >@ -->.<!-- >@ -->com</a>  </p>
                            </div>
                        </div><!-- end #navbar-collapse-1 -->
                    </nav><!-- end navbar navbar-default w3_megamenu -->
                </div><!-- end container -->

                <div class="home-popup-content"> 
                    <a href="javascript:void(0)" class="home-popup-close">
                        <img src="<?php echo resource('frontend')?>images/home-popup-close.png">
                    </a>
                    <div class="row warning-header">
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <h1>FRAUDULENT ALERT</h1>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <img class="logo-warning" src="<?php echo resource('frontend')?>images/warning-logo.png" alt="Expresscok"/>
                            <span class="trademark popup">&trade;</span>
                        </div>
                    </div>                                                       
                    <p>Unauthorized use of its business names, service marks and logos by persons or companies fraudulently representing themselves as EX Courier India Private Limited - Express International or as representatives of EX Courier India Private Limited - Express International </p> 
                    <a target="_blank" href="#test-modal" class="popup-modal call-action white-hover">Click for More Details</a>                    
                </div>

                <div id="test-modal" class="white-popup-block mfp-hide">
                    <p><b>Unauthorized use of EX Courier India Private Limited - Express International � Business Names, Service Marks and Logos</b>
EX Courier India Private Limited - Express International has been alerted to the unauthorized use of its business names, service marks and logos by persons or companies fraudulently representing themselves as EX Courier India Private Limited - Express International or as representatives of EX Courier India Private Limited - Express International.</p>
<p>Millions of fraudulent e-mails and sms messages are deployed daily. They claim to come from a wide variety of sources, and some claim to be from EX Courier India Private Limited - Express International or representing EX Courier India Private Limited - Express International. Fraudulent e-mail and sms messages, often referred to as "phishing" or brand "spoofing," are becoming increasingly common. These types of messages often use corporate logos, colors and legal disclaimers to make it appear as though they are real. They are sent in an attempt to trick people into sending money and providing personal information such as usernames, passwords and/or credit card details, and for the purpose of committing theft, identity theft and/or other crimes.</p>

<p>
    <h4>Recognizing Phishing Scam E-mails and sms messages</h4>
recognizing phishing scam e-mails and sms messages is key to protecting yourself against such theft and other crimes. Indicators that an e-mail or sms message might be fraudulent include:
   <ul>
    <li>Unexpected requests for money in return for delivery of a package or other item, personal and/or financial information, such as your Social Security number, bank account number, or other identification.</li>
    <li>Links to misspelled or slightly altered Web-site addresses. For example, variations on the correct Web-site address EX Courier India Private Limited - Express International .com, such as <a href="https://www.expresscok.com">www.expresscok.com</a> excourier.com</li>
    <li>Alarming messages and requests for immediate action, such as "Your account will be suspended within 24 hours if you don't respond" or claims that you've won the lottery or a prize.</li>
    <li>Spelling and grammatical errors and excessive use of exclamation points (!).</li>
</ul> 
</p>


<p>EX Courier India Private Limited - Express International does not request, via unsolicited mail, e-mail or sms messages, payment or personal information in return for goods in transit or in EX Courier India Private Limited - Express International custody. If you have received a fraudulent e-mail or sms message that claims to be from EX Courier India Private Limited - Express International , you can report it by forwarding it to <a href="mailto:info@expresscok.com">info@expresscok.com</a></p>

<p>If you have any questions or concerns about services provided by EX Courier India Private Limited - Express International , please review our services at <a href="mailto:info@expresscok.com">info@expresscok.com</a>  or contact Express customer service 0484 4000071
The Internet is an important channel connecting EX Courier India Private Limited - Express International  to its customers. While there is no foolproof method to prevent the unauthorized use of the EX Courier India Private Limited - Express International name, we continuously watch for such activity in order to help safeguard our customers' interests.</p>

<p>Thank you for helping us identifies and takes action against e-mail & sms fraud</p>

<hr>

<p> NOTE: EX Courier India Private Limited - Express International is not responsible for any charges or costs incurred as a result of fraudulent activity that abuses the EX Courier India Private Limited - Express International name, service marks and logos.</p>

<p>EX Courier India Private Limited - Express International does not require money transfers through third-party escrow services or online payment services prior to shipment delivery</p>

<p>The use of the EX Courier India Private Limited - Express International logo and name on these websites is unauthorized and our legal department will address this matter with the relevant authorities.</p>
<br/>
<p><a class="popup-modal-dismiss" href="#">CLOSE</a></p>
                </div>
